#!/bin/bash

<<doc
Name          : Nidhin S
Date          : 26/12/2022
Description   : Script for command line test
Sample input  : bash project.sh
Sample output :
doc

echo $'\e[1;34m'Hi user ..WELCOME...........$'\e[0m'
echo -e "\n"

#Options for the user to select
 echo "1. Signup
2. Signin "

#read the choice from the user
read -p "Enter the choice: " choice

#case statement to execute the selected option
case $choice in

#case statement for for signup option

1)

#loop to repeat if username or password error occur
option=y
while [ $option = y ]
do
    #storing the contents of user.csv to array
    arr=(`cat user.csv`)

    #read the user name
    read -p "Enter the user_name: " user_name

    #loop to check whether user name is already existing or not
    flag=0

    for i in ${arr[@]}
    do
	if [ $user_name = $i ]
	then
	    flag=1
	    echo " User_name is already existing. Please provide a new user_name"
	    break
	fi
    done

    #storing the user name to user.csv file if no match found
    if [ $flag -eq 0 ]
    then
	echo "$user_name" >> user.csv
	option=N
    fi
done

      #loop to check whether the user entered passwords are matching 
     while [ $passwd != $cnfrm_pwd ]
     do 
	 echo "Enter your password: "

	 # read the password from the user in hidden mode
	 read -s  passwd

	 #read the password again in hidden mode for confirmation
	 echo "Confirm your password: "
	 read -s cnfrm_pwd

	 #checking whether the two passwords are matching or not 
	 if [ $passwd = $cnfrm_pwd ]
	 then

	     #Storing the password to password.csv file
	    echo "$passwd" >> password.csv
	echo $'\e[1;32m'Your signup is successful ....$'\e[0m'
	else
	    echo
	echo $'\e[1;31m'Password is not matching...Please provide a valid password$'\e[0m'

       fi
	 done
	 ;;
 

  #case statement for signin process
     2)   
     
     #storing the contents of user.csv file to an array
     arr=(`cat user.csv`)

     #storing the contents of password.csv file to an array
     pswd=(`cat password.csv`)

     #loop to verify password and username
     pass=s
     while [ $pass = s ]
     do

     option=y
    while [ $option = y ]
    do

    read -p "Enter the user_name: " user_name
    flag=0
    
    #loop to get the index position of the given user name
    for i in `seq 0  $((${#arr[@]}-1))`
    do
	#checking match for user name in the array
	if [ $user_name = ${arr[$i]} ]
	then
	    flag=1
	    index=$i
	    option=N
	    break
	fi
    done

    if [ $flag -eq 0 ]
    then

	echo -e "\n Please provide a valid user_name"
	option=y
    fi
done  
    echo "Enter the password: "
    read -s passwd
    
    #checking whether the passwords for the coreesponding username are enetered or not
    if [ $passwd = ${pswd[$i]} ]

    then

	echo $'\e[1;32m'You are successfully logged in ....$'\e[0m'
        echo -e "\n"

       #Options for the user to select after signin process
	echo -e  " 1. Take the test
 2. Exit"
        echo "Enter the choice: "

	read usr_choice

	#case statement to execute the test
	case $usr_choice in

               #case statement to display the questions
	    1) total_line=`wc -l < question_bank.txt`
		for i in `seq 5 5 $total_line`
		do
		    head -$i question_bank.txt | tail -5

		    #loop to read the option from the user
		    for k in `seq 10 -1 1`
		    do
			echo -n -e "\rEnter the option: $k \c"

			#Timer
			read -t 1 ans

			if [ -n "$ans" ]
			then
			    break
			else

			    #assigning a equal to e if no option is entered
			    ans=e
			fi

		    done

		    #storing users answers to file
		    echo " $ans" >> user_answer.txt
	
	    	done

		echo $'\e[1;31m'******************************************************************RESULT PAGE**************************************************************$'\e[0m'
	
	        #storing correct answers to an array
		crct_1=(` cat correct_answer.txt`)

		#storing user answers to an array
		user_1=(`cat user_answer.txt`)

		total_mark=0

		#loops to obtain the result
		for i in `seq 5 5 $total_line`
		do
		    head -$i question_bank.txt | tail -5
		    indx=$((($i / 5) - 1))


		    #checking the users answers with correct answers
		    if [ ${crct_1[$indx]} = ${user_1[$indx]} ]
		    then
			 echo $'\e[1;32m'Correct answer$'\e[0m'
			total_mark=`expr $total_mark + 1`
                    
	           #To print timed out if no answer is enetred
		    elif [ ${user_1[$indx]} = e ]

		    then
	               	echo $'\e[1;31m'Not attempted...Timed out$'\e[0m'
		    else
			echo $'\e[1;31m'Wrong answer$'\e[0m'
		    fi
		done
	    
                #printing total marks
		echo $'\e[1;33m'Your total score is $total_mark$'\e[0m'
               
		#clearing users answer file at the end of each iteration
		> user_answer.txt
		;;
	esac

	break
    else
	echo $'\e[1;31m'Password is not matching...Please provide a valid password$'\e[0m'	
        pass=s
    fi
    done
    ;;
 
    #To exit out of the test
2) exit 0
    ;;

 *) echo "Please select a valid option"
    esac


